package Milestone2;

public class ConsoleStart {
	public static void main(String[] args) {
		AddressBook addressBook = new AddressBook();
		addressBook.open();
		
	}
}
